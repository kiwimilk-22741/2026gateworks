<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<project source="4.0.0" version="1.0">
  This file is intended to be loaded by Logisim-evolution v4.0.0(https://github.com/logisim-evolution/).

  <lib desc="#Wiring" name="0">
    <tool name="Pin">
      <a name="appearance" val="classic"/>
    </tool>
  </lib>
  <lib desc="#Gates" name="1"/>
  <lib desc="#Plexers" name="2"/>
  <lib desc="#Arithmetic" name="3"/>
  <lib desc="#Memory" name="4"/>
  <lib desc="#I/O" name="5"/>
  <lib desc="#TTL" name="6"/>
  <lib desc="#TCL" name="7"/>
  <lib desc="#Base" name="8"/>
  <lib desc="#BFH-Praktika" name="9"/>
  <lib desc="#Input/Output-Extra" name="10"/>
  <lib desc="#Soc" name="11"/>
  <main name="main"/>
  <options>
    <a name="gateUndefined" val="ignore"/>
    <a name="simlimit" val="1000"/>
    <a name="simrand" val="0"/>
  </options>
  <mappings>
    <tool lib="8" map="Button2" name="Poke Tool"/>
    <tool lib="8" map="Button3" name="Menu Tool"/>
    <tool lib="8" map="Ctrl Button1" name="Menu Tool"/>
  </mappings>
  <toolbar>
    <tool lib="8" name="Poke Tool"/>
    <tool lib="8" name="Edit Tool"/>
    <tool lib="8" name="Wiring Tool"/>
    <tool lib="8" name="Text Tool"/>
    <sep/>
    <tool lib="0" name="Pin"/>
    <tool lib="0" name="Pin">
      <a name="facing" val="west"/>
      <a name="type" val="output"/>
    </tool>
    <sep/>
    <tool lib="1" name="NOT Gate"/>
    <tool lib="1" name="AND Gate"/>
    <tool lib="1" name="OR Gate"/>
    <tool lib="1" name="XOR Gate"/>
    <tool lib="1" name="NAND Gate"/>
    <tool lib="1" name="NOR Gate"/>
    <sep/>
    <tool lib="4" name="D Flip-Flop"/>
    <tool lib="4" name="Register"/>
  </toolbar>
  <circuit name="main">
    <a name="appearance" val="logisim_evolution"/>
    <a name="circuit" val="main"/>
    <a name="circuitnamedboxfixedsize" val="true"/>
    <a name="simulationFrequency" val="1.0"/>
    <comp lib="0" loc="(250,210)" name="Pin">
      <a name="appearance" val="NewPins"/>
    </comp>
    <comp lib="0" loc="(250,230)" name="Pin">
      <a name="appearance" val="NewPins"/>
    </comp>
    <comp lib="0" loc="(470,210)" name="Pin">
      <a name="appearance" val="NewPins"/>
      <a name="facing" val="west"/>
      <a name="type" val="output"/>
    </comp>
    <comp loc="(470,210)" name="d_flipflop">
      <a name="appearance" val="logisim_evolution"/>
    </comp>
  </circuit>
  <vhdl name="d_flipflop">--------------------------------------------------------------------------------&#13;
-- Project :&#13;
-- File    :&#13;
-- Autor   :&#13;
-- Date    :&#13;
--&#13;
--------------------------------------------------------------------------------&#13;
-- Description :&#13;
--&#13;
--------------------------------------------------------------------------------&#13;
&#13;

LIBRARY ieee;
USE ieee.std_logic_1164.ALL;

ENTITY d_flipflop IS
    PORT (
        clk : IN std_logic;
        d   : IN std_logic;
        q   : OUT std_logic
    );
END d_flipflop;

ARCHITECTURE bhv OF d_flipflop IS
BEGIN
    PROCESS(clk)
    BEGIN
        IF rising_edge(clk) THEN
            q &lt;= d;
        END IF;
    END PROCESS;
END bhv;

</vhdl>
</project>
